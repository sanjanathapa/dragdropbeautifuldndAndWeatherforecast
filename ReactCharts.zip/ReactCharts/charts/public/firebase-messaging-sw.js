// public/firebase-messaging-sw.js
importScripts('https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.6.1/firebase-messaging-compat.js');


const firebaseConfig = {
  apiKey: "AIzaSyCQLVblKfk5aHX52uzxVN6B8sAm736HktM",
  authDomain: "fir-react-397f8.firebaseapp.com",
  projectId: "fir-react-397f8",
  databaseURL: "https://curious-sandbox-196209.firebaseio.com",
  storageBucket: "fir-react-397f8.appspot.com",
  messagingSenderId: "858598612961",
  appId: "1:858598612961:web:2e6fbb3dd311d958db7ca0",
  measurementId: "G-6D33T80Z4H"
};
firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

// Customize background notification handling here
messaging.onBackgroundMessage((payload) => {
  console.log('Background Message:', payload);
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
  };
  self.registration.showNotification(notificationTitle, notificationOptions);
});