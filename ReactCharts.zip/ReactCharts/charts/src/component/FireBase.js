// firebase.js
import { initializeApp } from '@firebase/app';
import { getMessaging, getToken, onMessage } from '@firebase/messaging';

// const firebaseConfig = {
//   // Your Firebase config here
// };

// const firebaseConfig = {
//     apiKey: "AIzaSyCYaTKjfam_qMXDnGfcdnBxScEq89VQtLk",
//     authDomain: "curious-sandbox-196209.firebaseapp.com",
//     databaseURL: "https://curious-sandbox-196209.firebaseio.com",
//     projectId: "curious-sandbox-196209",
//     storageBucket: "",
//     messagingSenderId: "1034032747860",
//   };

  const firebaseConfig = {
    apiKey: "AIzaSyCQLVblKfk5aHX52uzxVN6B8sAm736HktM",
    authDomain: "fir-react-397f8.firebaseapp.com",
    projectId: "fir-react-397f8",
    databaseURL: "https://curious-sandbox-196209.firebaseio.com",
    storageBucket: "fir-react-397f8.appspot.com",
    messagingSenderId: "858598612961",
    appId: "1:858598612961:web:2e6fbb3dd311d958db7ca0",
    measurementId: "G-6D33T80Z4H"
  };

const firebaseApp = initializeApp(firebaseConfig);
console.log(firebaseApp, "firebasae app")
const messaging = getMessaging(firebaseApp);
console.log("messaging>>>>>>>>>..", messaging)
const setupNotifications = async () => {
  try {
    // Request permission for notifications
    console.log(await Notification.requestPermission(), "rrrrrr")
    const permission = await Notification.requestPermission();
    console.log(permission, "permission>>")
    
    if (permission === 'granted') {
      console.log('Notification permission granted.');
      // Get the FCM token
      const token = await getToken(messaging);
      console.log('FCM Token--------------:', token);
    } else {
      console.log('Notification permission denied.');
    }
    // Handle foreground notifications
    onMessage(messaging, (payload) => {
      console.log('Foreground Message>>>>>>>', payload.notification.title);
      // Handle the notification or update your UI
    });
  } catch (error) {
    console.error('Error setting up notifications:', error);
  }
};
setupNotifications();
export { messaging, setupNotifications };