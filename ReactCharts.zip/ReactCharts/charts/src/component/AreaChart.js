import React, { useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const AreaChart = () => {
  const [chartData, setChartData] = useState({
    series: [
      {
        name: 'series1',
        data: [60, 80, 100, 110, 115, 125, 150]
      },
    //   {
    //     name: 'series2',
    //     data: [11, 32, 45, 32, 34, 52, 41]
    //   }
    ],
    options: {
      chart: {
        height: 350,
        type: 'area'
      },
      dataLabels: {
        enabled: true
      },
      stroke: {
        curve: 'smooth'
      },
      xaxis: {
        // type: 'datetime',
        categories: [
            "Mon",
            "Tue",
            "Wed",
            "Thu",
            "Fri",
            "Sat",
            "Sun"
          ]
      },
      tooltip: {
        x: {
          format: 'dd/MM/yy HH:mm'
        }
      }
    }
  });

  return (
    <div>
      <div>
        <ReactApexChart
          options={chartData.options}
          series={chartData.series}
          type="area"
          height={350}
        />
      </div>
    </div>
  );
};

export default AreaChart;