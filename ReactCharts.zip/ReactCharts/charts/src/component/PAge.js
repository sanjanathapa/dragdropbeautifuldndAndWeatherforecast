import React, { useState } from 'react';

const Page = () => {
  const allItems = [
    'Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5',
    'Item 6', 'Item 7', 'Item 8', 'Item 9', 'Item 10',
    'Item 11', 'Item 12', 'Item 13', 'Item 14', 'Item 15'
  ];

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const totalItems = allItems.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = allItems.slice(indexOfFirstItem, indexOfLastItem);

  const handleClick = (pageNumber) => {
    console.log(pageNumber, "page number")
    setCurrentPage(pageNumber);
  };

  return (
    <div>
      <h1>Pagination Example</h1>
      <ul>
        {currentItems.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
      <div>
        {Array.from({ length: totalPages }, (_, index) => {console.log(index, "index"); 
        return (
          <button key={index} onClick={() => handleClick(index + 1)}>
            {index + 1}
          </button>
        )})}
      </div>
    </div>
  );
};

export default Page;