// import React from 'react'
// import { Container, Row, Col, Modal, Button } from "react-bootstrap";
// import AreaChart from './AreaChart';
// import PieChart from './PieChart'


import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import AreaChart from './AreaChart';
import PieChart from './PieChart';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import {Link} from "react-router-dom"


// const Graph = () => {
//   return (
//    <>
//    <section>
//         <Container>
//               <Row>
//                 <Col md="2" sm="6" className="my-2">
//                   {/* <Link to="/piechart" className="text-dark h-100"> */}
//                   <AreaChart />
//                   {/* </Link> */}
//                 </Col>
//                 <Col lg="4" sm="6" className="my-2">
//                   {/* <Link to="/areachart" className="text-dark h-100"> */}
//                    <PieChart />
//                   {/* </Link> */}
//                 </Col>
//               </Row>
//         </Container>
//       </section></>
//   )
// }

// export default Graph


const Graph = () => {
  return (
    <>
      <section className="dashboard py-2">
        <Container>
          <Row>
            <Col lg={6}  xs={6} className="my-2">
              <AreaChart />
            </Col>
            <Col lg={6} xs={6} className="my-2">
              <PieChart />
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Graph;