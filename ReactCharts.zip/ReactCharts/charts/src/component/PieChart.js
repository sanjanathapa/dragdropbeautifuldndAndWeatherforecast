// src/PieChart.js
import React from 'react';
import Chart from 'react-apexcharts';

const PieChart = () => {
    const options = {
        chart: {
            type: 'pie',
        },
        labels: ['Apple', 'Mango', 'Orange', 'Watermelon', 'sanjana'],
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    };

    const series = [44, 40, 15, 13, 43]; // Data for the pie chart

    return (
        <div>
            <Chart options={options} series={series} type="pie" width="480" />
        </div>
    );
};

export default PieChart;

// import React, { Component } from "react"
// import ReactEcharts from "echarts-for-react"
// import Loader from "../../components/Common/Loader"

// import { STATUS_COLORS } from "helpers/contants"

// const Pie = props => {
//   const getOption = () => {
//     const order = props?.data || []
//     return {
//       toolbox: {
//         show: false,
//       },
//       tooltip: {
//         trigger: "item",
//         formatter: "{a} <br/>{b} : {c} ({d}%)",
//       },
//       legend: {
//         show: true,
//         position: "bottom",
//         horizontalAlign: "center",
//         verticalAlign: "middle",

//         data: order.map(item => props.t(item._id)),
//         textStyle: {
//           color: ["#74788d"],
//         },
//       },
//       color: order.map(item => STATUS_COLORS[item._id]),
//       series: [
//         {
//           name: props.t("total_sales"),
//           type: "pie",
//           radius: "55%",
//           center: ["50%", "60%"],
//           data: order.map(item => ({
//             value: item.count,
//             name: props.t(item._id),
//           })),
//           itemStyle: {
//             emphasis: {
//               shadowBlur: 10,
//               shadowOffsetX: 0,
//               shadowColor: "rgba(0, 0, 0, 0.5)",
//             },
//           },
//         },
//       ],
//     }
//   }
//   return (
//     <React.Fragment>
//       {props.loading ? (
//         <Loader height={280} />
//       ) : (
//         <ReactEcharts style={{ height: "300px" }} option={getOption()} />
//       )}
//     </React.Fragment>
//   )
// }
// export default Pie
