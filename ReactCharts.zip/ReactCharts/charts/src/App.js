import logo from './logo.svg';
import './App.css';
// import PieChart from './component/PieChart';
import AreaChart from './component/AreaChart';
import TableComp from './component/TableComp';
import { useEffect } from 'react';
import Graph from './component/Graph';
import 'bootstrap/dist/css/bootstrap.css';
import Table from './component/Table';
import "rc-pagination/assets/index.css";
import Page from './component/PAge';
import SocialLogin from './component/SocialLogin';
import { setupNotifications } from './component/FireBase';
import { Register } from './component/Register';
import { UseVisibilityChange } from './component/UseVisibilityChange';
import { toastNotification, sendNativeNotification } from './component/notifications';

 function App() {
  const isForeground = UseVisibilityChange();
  console.log(isForeground, "idRfjdfhjd")
  useEffect(() => {    
    setupNotifications((message) => {
      if (isForeground) {
        // App is in the foreground, show toast notification
        toastNotification({
          title: "this sis good",
          body: "this is body",
          status: "info",
        });
      } else {
        // App is in the background, show native notification
        sendNativeNotification({
          title: "this is newie",
          body: "this sis jfdf"
        });
      }
    });
  }, []);
  return (
    <div className="App">
       <div class="heading">Campaign List</div>
     {/* <PieChart /> */}
     {/* <AreaChart /> */}
     {/* <TableComp /> */}
     {/* <Graph /> */}
     {/* <div style={{position: "absolute", left: "33%"}}><Table /></div> */}
     {/* <Page /> */}
     <SocialLogin />

    </div>
  );
}

export default App;
