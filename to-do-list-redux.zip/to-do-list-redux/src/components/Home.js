import React, { useState } from "react";
import { Button } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { addList } from "../store/actions";
import Todo from "./Todo";
import { useDispatch, useSelector } from "react-redux";

const Home = () => {
  const [data, setData] = useState("");
  console.log(data, "data");
  
  const dispatch = useDispatch();

  const addData = () => {
    console.log("checkdata", data)
    dispatch(addList(data));
    setData("");
  };

  return (
    <>
      <div className="container">
        <section className="mt-3 text-center">
          <h3>Add Your List Here</h3>

          <div className="todo col-lg-5 mx-auto d-flex justify-content-between align-items-center">
            <input
              name="task"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="form-control"
              placeholder="Enter your list "
            />
            <Button
              variant="contained"
              onClick={() => addData()}
              style={{ background: "#ee5253" }}
              className="mx-2"
            >
              <AddIcon />
            </Button>
          </div>

          <Todo />
        </section>
      </div>
    </>
  );
};

export default Home;
