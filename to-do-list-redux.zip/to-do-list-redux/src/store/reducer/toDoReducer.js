
const InitialState = {
    list_data : []
}


export const toDoReducer = (state = InitialState, action) => {

    console.log("action------------", action)
    switch (action.type) {
        case "ADD_LIST":
            return {
                ...state,
                list_data:[...state.list_data, action.payload]
            }

            case "DELETE_LIST":

            const dltdata = state.list_data.filter((ele, k) => k !== action.payload)  //returning remianing value
            console.log(dltdata, "d--------------")

            return {
                ...state,
                list_data: dltdata
            }

            case "EDIT_LIST" : 
            // const updatedata = state.User_data.map((ele,k)=> {console.log(ele, "ele")  return {k == action.d ? action.payload : ele}})
            const updatedata = state.list_data.map((ele, k) => {
                console.log(ele, "ele");
                return k === action.id ? action.payload : ele;
            });
            console.log(updatedata, "updated data")
            return {
                ...state,
                list_data: updatedata
            }
        
        default:
            return state
    }
}