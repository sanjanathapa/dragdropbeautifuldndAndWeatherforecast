import { combineReducers } from "redux";
import { toDoReducer } from "./toDoReducer";

const rootreducers = combineReducers({
  toDoReducer:toDoReducer,
});

export default rootreducers;