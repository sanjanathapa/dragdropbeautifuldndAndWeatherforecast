
export const addList = (item) =>{
    console.log(item, "item")
    return {
        type: "ADD_LIST",
        payload: item
    }
    
}

export const deleteList = (id) =>{
    console.log(id, "payload delet id")
    return {
        type: "DELETE_LIST",
        payload: id
    }
}

export const editList = (item, id) =>{
    console.log(item, id, "item and id")
    return {
        type: "EDIT_LIST",
        payload: item,
        id
    }
}