import {Server } from "socket.io";
import { createServer} from "http";

const httpServer = createServer();
const io = new Server(httpServer, {
    cors: {
        origin: "*"
    }
});  //it takes https server or post


//add event ghandker

//listening events
io.on("connection", (socket)=>{
    socket.emit("welcome", 'Welcome To the channel');

    socket.on('msg', (data)=>{
        console.log("mesage from client", data)

    })

})
httpServer.listen(3003, ()=>{
    console.log("server is running")
})