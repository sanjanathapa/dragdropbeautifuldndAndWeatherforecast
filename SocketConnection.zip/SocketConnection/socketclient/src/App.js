import logo from './logo.svg';
import { useEffect } from "react"
import './App.css';
import { io } from "socket.io-client";

//Initializing the connection
const socket = io("http://localhost:3003");

function App() {
  useEffect(() => {
    //listen to the connection that we are making to the server
  socket.on('connect', ()=>{
    //can listen msg that is emitting from the server
    socket.on('welcome', (data)=>{
      console.log("msg from server", data)
    })

    //send msg to the server
    socket.emit('msg', "Thanks for cionnecting server")
  })
  
    // return () => {
    //   socket.off("connect")
    // }
  }, 
  [])
  
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
